import React, { useState, useRef, useEffect } from 'react';
import * as faceapi from 'face-api.js';
import WebcamCapture from './Components/WebcamCapture';
import VideoUpload from './Components/VideoUpload';

const loadModels = async () => {
  const MODEL_URL = '/models';
  await faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL + '/ssd_mobilenetv1');
  await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL + '/face_landmark_68');
  await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL + '/face_recognition');
};

const compareFaces = async (liveImage, videoElement) => {
  const img = await faceapi.fetchImage(liveImage);
  const liveDescriptor = await faceapi
    .detectSingleFace(img)
    .withFaceLandmarks()
    .withFaceDescriptor();

  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d');
  canvas.width = videoElement.videoWidth;
  canvas.height = videoElement.videoHeight;

  const interval = setInterval(async () => {
    context.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
    const frame = canvas.toDataURL('image/jpeg');
    const frameImg = await faceapi.fetchImage(frame);

    const detection = await faceapi
      .detectSingleFace(frameImg)
      .withFaceLandmarks()
      .withFaceDescriptor();

    if (detection) {
      const distance = faceapi.euclideanDistance(
        liveDescriptor.descriptor,
        detection.descriptor
      );
      if (distance < 0.6) {
        alert('Match Found!');
        clearInterval(interval);
      }
    }
  }, 1000);
};

const App = () => {
  const [liveImage, setLiveImage] = useState(null);
  const [capturedImage, setCapturedImage] = useState(null); // State for captured image
  const [videoSrc, setVideoSrc] = useState(null);
  const [modelsLoaded, setModelsLoaded] = useState(false);
  const [cameraActive, setCameraActive] = useState(true); // State to toggle camera
  const videoRef = useRef(null);
  const webcamStreamRef = useRef(null); // Ref to store webcam stream

  useEffect(() => {
    const loadAllModels = async () => {
      await loadModels();
      setModelsLoaded(true);
    };
    loadAllModels();
  }, []);

  useEffect(() => {
    if (modelsLoaded && liveImage && videoSrc && videoRef.current) {
      compareFaces(liveImage, videoRef.current);
    }
  }, [modelsLoaded, liveImage, videoSrc]);

  const handleCapture = (image, stream) => {
    setCapturedImage(image); // Save the captured image
    setLiveImage(image); // Set the live image for face comparison
    setCameraActive(false); // Stop the camera
    if (stream) {
      webcamStreamRef.current = stream; // Save the webcam stream
      // Stop the webcam stream
      stream.getTracks().forEach((track) => track.stop());
    }
  };

  const handleRestartCamera = () => {
    setCapturedImage(null); // Clear the captured image
    setCameraActive(true); // Reactivate the camera
  };

  return (
    <div>
      <h1>Face Recognition App</h1>
      {!modelsLoaded && <p>Loading models, please wait...</p>}
      {cameraActive ? (
        <WebcamCapture onCapture={handleCapture} />
      ) : (
        <>
          <img src={capturedImage} alt="Captured" width="300" height="200" />
          <button onClick={handleRestartCamera}>Start Camera</button>
        </>
      )}
      <VideoUpload onVideoSelected={setVideoSrc} />
      {videoSrc && (
        <video ref={videoRef} src={videoSrc} controls width="300" height="200" />
      )}
    </div>
  );
};

export default App;