const createExpoWebpackConfigAsync = require('@expo/webpack-config');

module.exports = async function (env, argv) {

  console.log('Environment:', env);
  console.log('Arguments:', argv);

  const config = await createExpoWebpackConfigAsync(env, argv);

  console.log('✅ Custom Webpack config loaded');

  // Add alias for tslib
  config.resolve.alias = {
    ...(config.resolve.alias || {}),
    tslib: require.resolve('tslib'),
  };

  return config;
};
